import axios from "axios";
import React, { useState } from "react";
import { View, Text, TextInput, Button, Image, Alert } from "react-native";


const ScraperScreen = () => {
  const [url, setUrl] = useState("");
  const [product, setProduct] = useState(null);

  const handleScrape = async () => {
    if (!url) {
      Alert.alert("Error", "Please enter a product URL");
      return;
    }

    try {
      // const response = await api.get(`/scrape?url=${encodeURIComponent(url)}`);
      const response=await axios.get("http://localhost:3000/scrape",{
        params:{
          url: url
        }
      });
      // const data = response.data;
      if (response.data) {
        setProduct(response.data);
      } else {
        Alert.alert("Error", "Failed to fetch product details");
      }
    } catch (error) {
      Alert.alert("Error", "Something went wrong. Try again.");
    }
  };

  return (
    <View>
      <Text>Enter Product URL:</Text>
      <TextInput placeholder="Product URL" onChangeText={setUrl} />
      <Button title="Scrape Product" onPress={handleScrape} />

      {product && (
        <View>
          <Text>{product.title}</Text>
          <Text>{product.price}</Text>
          <Image source={{ uri: product.imageUrl }} style={{ width: 100, height: 100 }} />
        </View>
      )}
    </View>
  );
};

export default ScraperScreen;