import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import axios from "axios";

export default function RegisterScreen() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleRegister = async () => {
    try {
      const response = await axios.post("http://localhost:3000/register", { username, password });
      
      if (response.data.success) {
        Alert.alert("Success", "Registration successful!");
        router.push("/login");
      } else {
        Alert.alert("Error", response.data.error);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to register");
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 20, backgroundColor: "#E3F2FD" }}>
      
      {/* App Name with Styling */}
      <Text style={{ 
        fontSize: 36, 
        fontWeight: "bold", 
        color: "#1565C0", 
        marginBottom: 20, 
        textAlign: "center", 
        textShadowColor: "rgba(0, 0, 0, 0.2)", 
        textShadowOffset: { width: 2, height: 2 }, 
        textShadowRadius: 5
      }}>
        Unified Shop
      </Text>

      {/* Registration Form */}
      <View style={{ width: "100%", maxWidth: 400, padding: 20, backgroundColor: "#BBDEFB", borderRadius: 15, shadowColor: "#000", shadowOpacity: 0.2, shadowRadius: 10, elevation: 5, alignItems: "center" }}>
        
        <Text style={{ fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 20, color: "#0D47A1" }}>Register</Text>
        
        <TextInput
          placeholder="Username"
          placeholderTextColor="#0D47A1"
          style={{ borderWidth: 1, borderColor: "#64B5F6", borderRadius: 25, padding: 12, marginBottom: 10, backgroundColor: "#E3F2FD", color: "#0D47A1", width: "100%" }}
          value={username}
          onChangeText={setUsername}
        />
        
        <TextInput
          placeholder="Password"
          placeholderTextColor="#0D47A1"
          secureTextEntry
          style={{ borderWidth: 1, borderColor: "#64B5F6", borderRadius: 25, padding: 12, marginBottom: 20, backgroundColor: "#E3F2FD", color: "#0D47A1", width: "100%" }}
          value={password}
          onChangeText={setPassword}
        />

        {/* Register Button */}
        <TouchableOpacity
          onPress={handleRegister}
          style={{
            backgroundColor: "#1565C0",
            padding: 15,
            borderRadius: 25,
            alignItems: "center",
            marginBottom: 10,
            width: "100%",
            shadowColor: "#000",
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 4,
          }}
        >
          <Text style={{ color: "white", fontSize: 16, fontWeight: "bold" }}>Register</Text>
        </TouchableOpacity>

        {/* Login Redirect */}
        <TouchableOpacity onPress={() => router.push("/login")}>
          <Text style={{ color: "#0D47A1", textAlign: "center", marginTop: 10 }}>Already have an account? Login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
