import { View, Text, TextInput, TouchableOpacity, Alert, Image, Pressable, StyleSheet, ActivityIndicator } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen() {
  const [url, setUrl] = useState("");
  const [product, setProduct] = useState(null);
  const [showMenu, setShowMenu] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const handleScrape = async () => {
    if (!url) {
      Alert.alert("Error", "Please enter a URL");
      return;
    }

    setIsLoading(true);
    setProduct(null); // Clear previous product
    
    try {
      const response = await fetch(`http://localhost:3000/scrape?url=${encodeURIComponent(url)}`);
      const data = await response.json();
      if (data.error) {
        Alert.alert("Error", data.error);
      } else {
        setProduct(data);
      }
    } catch (error) {
      console.error("Scraping error:", error);
      Alert.alert("Error", "Failed to fetch product details");
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setUrl("");
    setProduct(null);
  };

  const handleLogout = () => {
    setShowMenu(false);
    router.replace('/login');
  };

  return (
    <View style={styles.container}>
      {/* Attractive Header */}
      <View style={styles.header}>
        <Text style={styles.appTitle}>Unified Shop</Text>
        <Pressable onPress={() => setShowMenu(!showMenu)} style={styles.menuButton}>
          <Ionicons name="ellipsis-vertical" size={24} color="#6a0dad" />
        </Pressable>
        
        {/* Dropdown menu */}
        {showMenu && (
          <View style={styles.menu}>
            <Pressable onPress={handleLogout} style={styles.menuItem}>
              <Text style={styles.menuItemText}>Logout</Text>
            </Pressable>
          </View>
        )}
      </View>

      {/* Centered Content */}
      <View style={styles.contentContainer}>
        <View style={styles.scraperContainer}>
          <Text style={styles.scraperTitle}>Search Product</Text>
          <View style={styles.inputContainer}>
            <TextInput
              placeholder="Enter product URL"
              placeholderTextColor="#999"
              style={styles.input}
              value={url}
              onChangeText={setUrl}
            />
            {url && (
              <Pressable onPress={() => setUrl("")} style={styles.clearInputButton}>
                <Ionicons name="close-circle" size={20} color="#999" />
              </Pressable>
            )}
          </View>
          <TouchableOpacity 
            onPress={handleScrape} 
            style={[styles.button, (isLoading || !url) && styles.disabledButton]}
            disabled={isLoading || !url}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Search</Text>
            )}
          </TouchableOpacity>
        </View>

        {isLoading && (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#6a0dad" />
            <Text style={styles.loadingText}>Fetching product details...</Text>
          </View>
        )}

        {product && !isLoading && (
          <View style={styles.productContainer}>
            <Text style={styles.productTitle}>{product.title}</Text>
            <Text style={styles.productPrice}>{product.price}</Text>
            <Image source={{ uri: product.imageUrl }} style={styles.productImage} />
            <Text style={styles.productSource}>Source: {product.websiteName}</Text>
            
            <TouchableOpacity onPress={handleClear} style={styles.clearButton}>
              <Text style={styles.clearButtonText}>Clear Search</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f5ff",
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 50,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 10,
  },
  appTitle: {
    flex: 1,
    fontSize: 28,
    fontWeight: 'bold',
    color: '#6a0dad',
    textAlign: 'center',
    fontFamily: 'sans-serif-condensed',
    textShadowColor: 'rgba(106, 13, 173, 0.2)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  menuButton: {
    padding: 8,
    position: 'absolute',
    right: 20,
    top: 50,
  },
  menu: {
    position: 'absolute',
    right: 20,
    top: 80,
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 10,
    minWidth: 120,
  },
  menuItem: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  menuItemText: {
    fontSize: 16,
    color: '#333',
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  scraperContainer: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  scraperTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#6a0dad',
    textAlign: 'center',
    marginBottom: 20,
  },
  inputContainer: {
    position: 'relative',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    backgroundColor: "#fafafa",
    color: '#333',
    paddingRight: 40, // Make space for clear button
  },
  clearInputButton: {
    position: 'absolute',
    right: 12,
    top: 16,
  },
  button: {
    backgroundColor: "#6a0dad",
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: "center",
    shadowColor: "#6a0dad",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  disabledButton: {
    backgroundColor: "#b39ddb",
    opacity: 0.7,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  productContainer: {
    marginTop: 30,
    padding: 20,
    backgroundColor: "#fff",
    borderRadius: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    alignItems: "center",
  },
  productTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
    marginBottom: 8,
  },
  productPrice: {
    fontSize: 22,
    fontWeight: 'bold',
    color: "#6a0dad",
    marginVertical: 8,
  },
  productImage: {
    width: 220,
    height: 220,
    borderRadius: 12,
    marginVertical: 15,
    resizeMode: 'contain',
  },
  productSource: {
    fontSize: 16,
    color: "#666",
    fontStyle: 'italic',
  },
  loadingContainer: {
    marginTop: 30,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#6a0dad',
  },
  clearButton: {
    marginTop: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
  },
  clearButtonText: {
    color: '#6a0dad',
    fontWeight: 'bold',
  },
});